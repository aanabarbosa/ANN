import numpy as np
import matplotlib.pyplot as plt


def best_poly(x, y, grau=1):
    k = grau + 1
    A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]
    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if (p == 0):
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if i > 0:
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))
    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a * np.exp(b * x)


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


if __name__ == '__main__':

    # x = [0.0002, 0.2662, 0.3985, 0.5738, 0.7829, 0.9648, 1.0205, 1.2178, 1.4909, 1.6213, 1.7607, 1.8625]
    # y = [2.1083, 8.0737, 8.0362, 12.0345, 16.1407, 24.9392, 22.5032, 32.3087, 50.3369, 60.3648, 76.9175, 91.3091]
    x = [0.0053, 0.2374, 0.475, 0.5943, 0.7422, 0.877,
         1.128, 1.2872, 1.4394, 1.6664, 1.7751, 1.9783]
    y = [3.7336, 5.5097, 8.3302, 9.4233, 12.8211, 15.7562,
         23.3201, 30.3166, 40.2952, 56.2558, 65.1611, 92.8711]
    x_values = [1.0066, 1.3637, 1.8125]
    y_ = np.log(y)

    grau = 1

    a0, a1 = best_poly(x, y_, grau)

    print(f'{a0 = } e {a1 = }')

    a = np.exp(a0)
    b = a1

    print(f'{a = } e {b = }')

    p = build_func(a, b)

    # x_values = [0.1435, 1.1136, 1.1948]

    for xi_v in x_values:
        print(p(xi_v))

    def q(x):
        return p(x)

    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 200)
    qt = [q(ti) for ti in t]

    plt.plot(t, qt, color='r')
    plt.show()
