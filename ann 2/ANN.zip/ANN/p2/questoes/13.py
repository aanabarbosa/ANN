import matplotlib.pyplot as plt
import numpy as np


def bestpoly(x, y, grau):
    k = grau + 1
    A = np.zeros((k, k))
    # A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]

    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if p == 0:
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if(i > 0):
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))

    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a * x ** b


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


def modelo(x):
    a, b = -1, 5
    erro = a + (b-a) * np.random.random()
    return 1.36 * x ** 3.89 + erro


def main():

    x = [0.3995, 0.97, 2.0343, 2.7567, 3.9472, 4.8679,
         5.1749, 6.0818, 7.238, 7.8686, 8.9499, 9.7128]
    y = [4.9393, 4.6405, 4.1364, 3.7495, 3.3321, 3.2177,
         3.2578, 3.4545, 3.5728, 3.8718, 4.6922, 5.1904]
    values = [2.4218, 6.6672, 7.1633]
    # x = np.linspace(1, 3, 20)
    print(f'{x = }')
    # y = [modelo(xi) for xi in x]
    print(f'{y = }')

    # transladar os pontos para cima
    k = abs(min(y)) + 1
    yt = [yi + k for yi in y]
    print(f'{y = }')

    x_ = np.log(x)
    y_ = np.log(y)

    grau = 1

    a0, a1 = bestpoly(x_, y_, grau)

    a = np.exp(a0)
    b = a1

    print(f'{a0 = } e {a1 = }')

    p = build_func(a, b)

    def q(x):
        return p(x) - k

    for xi_v in values:
        print(p(xi_v))

    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 200)
    pt = [p(ti) for ti in t]
    plt.plot(t, pt)
    plt.show()


main()
