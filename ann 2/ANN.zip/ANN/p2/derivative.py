

def diff_a(f, x, h):
    # primeira derivada de f no ponto x0
    return (f(x + h) - f(x)) / h

def diff_b(f, x, h):
    # segunda derivada de f no ponto x0
    return 
    # return diff_a(f, x0, -h)


if __name__ == '__main__':

    def f(x):
        return x ** x

    x0 = 2
    hs = [10 ** -i for i in range(1, 10)]

    print(hs)

    for h in hs:
        # print(f'diff_a(f, {x0}, {h}) = {diff_a(f, x0, h)}')
        print(f'diff_b(f, {x0}, {h}) = {diff_b(f, x0, h)}')
