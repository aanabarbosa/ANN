import math


def romberg(col1):
    n = len(col1)
    col1 = [item for item in col1]

    for j in range(n - 1):     # percorrer as colunas
        temp_col = [0] * (n - 1 - j)
        for i in range(n - 1 - j):  # percorrer as linhas
            power = j + 1
            temp_col[i] = ((4 ** power) * col1[i + 1] -
                           col1[i]) / (4 ** power - 1)
        col1[:n - 1 - j] = temp_col
        print(f'F_{j+2}', temp_col)
    return col1[0]


def trapz(f, a, b, h):
    n = int((b - a)/h)
    soma = 0
    for k in range(1, n):
        soma += f(a + k * h)
    return (h/2) * (f(a) + 2 * soma + f(b))


def f1(x):
    return (x+1/x)**2


def f2(x):
    return math.exp(x)*math.sin(x)/(1+x**2)


def f3(x):
    return math.exp(-x**2)


def f4(x):
    return math.sqrt(1+x**2)


def f5(x):
    return math.cos(-x**2/3)


# func = ['(x+1/x)**2', 'math.exp(x)*math.sin(x)/(1+x**2)',
#         'math.exp(-x**2)', 'math.sqrt(1+x**2)', 'math.cos(-x**2/3)']
# a = [0.5, 0.2, -1.38, 0.53, 0.89]
# b = [1.5, 1.2, -0.38, 1.53, 1.89]
# order = [8, 6, 4, 4, 6]
# h = [0.2, 0.2, 0.125, 0.5, 0.25]

a = 0.89
b = 1.89
order = 6
h = 0.25
hs = [h / (2 ** i) for i in range(order)]
col1 = [trapz(f5, a, b, hi) for hi in hs]
# print('F_1', col1)
#col1 = [3.0310524239033874, 3.6293572422069156, 3.6716466952512974, 3.676838347983398, 3.678026112481302]
r = romberg(col1)
print(r)

# for index, item in enumerate(func):
#     func_ = func[index]
#     a_ = a[index]
#     b_ = b[index]
#     order_ = order[index]
#     h_ = h[index]

#     hs = [h_ / 2 ** i for i in range(order_)]
#     col1 = [trapz(func_, a_, b_, hi) for hi in hs]
#     r = romberg(col1)
#     print(index, r)
