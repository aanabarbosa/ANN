# requer número impar de pontos
import math


def simps(f, a, b, n):
    h = (b - a) / n
    soma_impar = sum([f(a + k * h) for k in range(1, n, 2)])
    soma_par = sum([f(a + k * h) for k in range(2, n, 2)])
    return (h/3) * (f(a) + 4 * soma_impar + 2 * soma_par + f(b))


def f(x):
    return math.sqrt(1 + (math.cos(x)**2))


a, b = 1.193, 2.536
# nro de subintervalos, n/2 é o nro de parabolas, n+1 é o nro de pontos na partição
n = [4, 16, 46, 68, 80, 120, 138, 172, 176, 208, 426]
for ni in n:
    i1 = simps(f, a, b, ni)
    print(i1)


def g(x):
    return math.cos(x ** 2)


x = [0.0,
     0.75,
     1.5,
     2.25,
     3.0,
     3.75,
     4.5,
     5.25,
     6.0,
     6.75,
     7.5,
     8.25,
     9.0,
     9.75,
     10.5,
     11.25,
     12.0, ]
y = [9.94,
     9.53,
     9.0,
     8.72,
     8.02,
     7.59,
     7.45,
     6.84,
     6.65,
     5.93,
     5.72,
     5.24,
     4.89,
     4.3,
     4.17,
     3.71,
     3.2, ]

soma = 0
xy = zip(x, y)

for n in range(2, len(x), 2):  # lista de x e y removidos os primeiros elementos
    print(n, x[n-2], x[n-1], x[n])
    soma += ((x[n-1] - x[n-2])/3) * (y[n-2] + 4*y[n-1] + y[n])

print(soma)
