# requer número impar de pontos
import math


def simps(f, a, b, n):
    h = (b - a) / n
    soma_impar = sum([f(a + k * h) for k in range(1, n, 2)])
    soma_par = sum([f(a + k * h) for k in range(2, n, 2)])
    return (h/3) * (f(a) + 4 * soma_impar + 2 * soma_par + f(b))


def f(x):
    return (9 + 4*pow(math.cos(0.21*x), 2)) * (5*pow(math.e, -0.48*x) + 2*pow(math.e, 0.17*x))


a, b = 1.67, 8.09
# nro de subintervalos, n/2 é o nro de parabolas, n+1 é o nro de pontos na partição
n = [12]
for ni in n:
    i1 = simps(f, a, b, ni)
    print(i1)
