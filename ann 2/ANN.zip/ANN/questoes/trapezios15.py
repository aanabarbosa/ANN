x = [0.0,
     0.75,
     1.5,
     2.25,
     3.0,
     3.75,
     4.5,
     5.25,
     6.0,
     6.75,
     7.5,
     8.25,
     9.0,
     9.75,
     10.5,
     11.25,
     12.0, ]
y = [9.94,
     9.53,
     9.0,
     8.72,
     8.02,
     7.59,
     7.45,
     6.84,
     6.65,
     5.93,
     5.72,
     5.24,
     4.89,
     4.3,
     4.17,
     3.71,
     3.2, ]
soma = 0
xy = zip(x, y)

for a2, b2 in zip(x[1:], y[1:]):  # lista de x e y removidos os primeiros elementos
    for a1, b1 in zip(x, y):
        soma += ((a2-a1) * (b2 + b1))/2.0
        x.pop(0)  # removendo os primeiros elementos das listas de x e y
        y.pop(0)
        break

print('soma de verdade?', soma)
