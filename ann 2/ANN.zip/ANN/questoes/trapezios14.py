x = [0.0,
     10.0,
     20.0,
     30.0,
     40.0,
     50.0,
     60.0]

y = [234.84,
     107.35,
     295.12,
     148.36,
     202.6,
     178.02,
     254.14, ]
soma = 0
xy = zip(x, y)

for a2, b2 in zip(x[1:], y[1:]):  # lista de x e y removidos os primeiros elementos
    for a1, b1 in zip(x, y):
        soma += ((a2-a1) * (b2 + b1))/2.0
        x.pop(0)  # removendo os primeiros elementos das listas de x e y
        y.pop(0)
        break

print('soma de verdade?', soma)
