import matplotlib.pyplot as plt
import numpy as np
import math

def romberg(col1):
   col1 = [item for item in col1]
   n = len(col1)
   for j in range(n - 1):
      tmp_coluna = [0] * (n - 1 - j)
      for i in range(n - 1 - j):
         power = j + 1 # é igual ao num da coluna anterior
         tmp_coluna[i] = (4 ** power * col1[i + 1] - col1[i]) / (4 ** power - 1)
      col1[:n - 1 - j] = tmp_coluna
    #   print(f'F_{j+2}', tmp_coluna)
   return col1[0] #a aprox. procurada

def trapz(f, a, b, n):
    h = abs(b-a) / n
    sum_fx = 0
    for i in range(1, n):
        sum_fx += f(a+i*h)
    return (f(a) + 2 * sum_fx + f(b)) * h/2

def trapz2(f, a, b, h):
    n = int((b - a)/h)
    soma = 0
    for k in range(1, n):
        soma += f(a + k * h)
    return (h/2) * (f(a) + 2 * soma + f(b))


def coeffs(func ,funcs):
    # mudar aqui
    a = -2.063
    b = 2.192

    n = len(funcs)
    A = np.zeros((n, n), dtype=float)
    B = np.zeros(n, dtype=float)
    for i in range(n):
        for j in range(i,n):
            def f_ji(x):
                return funcs[j](x) * funcs[i](x)

            # mudar aqui
            k = 4
            h = (b-a)/10
            hs = [h / 2 ** i for i in range(k)]
            col1 = [trapz2(f_ji, a, b, hi) for hi in hs]
            r = romberg(col1)
            A[i][j] = r

            if i != j:
                A[j][i] = A[i][j]
        ffi = lambda x: func(x) * funcs[i](x)

        # mudar aqui
        k = 4
        h = (b-a)/10
        hs = [h / 2 ** i for i in range(k)]
        col1 = [trapz2(ffi, a, b, hi) for hi in hs]
        r = romberg(col1)
        B[i] = r

    return np.linalg.solve(A,B)

def build_func(s, var: str='x'):
    scope = {}
    scope['math'] = math
    func = f'def f({var}): return {s}'
    exec(func, scope)
    return scope['f']

def comb(c, funcs):
    def g(x):
        return sum(ci * fi(x) for ci, fi in zip(c, funcs))
    return g

if __name__ == '__main__':

    # mudar aqui
    a = -2.063
    b = 2.192
    x1 = -1.483
    x2 = -0.262
    x3 = 1.809

    def func(x):
        # mudar aqui
        return x**2 * math.cos(x * math.sin(math.log(1 + x**2)))

    funcs_str = ['2', 'x - 1', 'x**2 + 1', 'x**3 + x - 3', '0.5 * x**4 - 3 * x**2 + 1', 'x**5 - 4 * x + 2', 'x**7-x']
    funcs = []
    for func_str in funcs_str:
        f = build_func(func_str)
        funcs.append(f)

    c = coeffs(func, funcs)
    print('coefs = ', c)

    t = np.linspace(a, b, 200)
    ft = [func(ti) for ti in t]
    plt.plot(t, ft, color ='blue')

    g = comb(c, funcs)
    print(g(x1))
    print(g(x2))
    print(g(x3))
    gt = [g(ti) for ti in t]

    plt.plot(t, gt, color ='orange')

    plt.show()
