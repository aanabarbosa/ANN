import matplotlib.pyplot as plt
import numpy as np


def euler(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        y0 += h * f(x0, y0)
        x0 += h
        vals.append([x0, y0])
        print(f'x_{k+1} = {x0}, y_{k+1} = {y0}')
    return vals


def euler_mid(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + h / 2.0, y0 + (h/2.0) * m1)
        y0 += + h * m2
        x0 += + h
        print(f'x_{k+1} = {x0}, y_{k+1} = {y0}')
        vals.append([x0, y0])
    return vals


if __name__ == '__main__':

    def f(x, y):
        return 0.0759*x
    
    def df(x, y):
        return 0.0759

    x0 = 0
    y0 = 1
    h = 0.0625
    n = 1737412  # na questao k = n
    vals = euler_mid(f, x0, y0, h, n)
    # print(vals)
    # x_, y_ = zip(*vals)

    # jogar no wolfram alpha
    # solve p'(t)= k*p, p(0)= 1737412
    # 1737412*e^(0.0759*1)

    # resposta correta = 1874078.7244123

    # 4.884386791220155
    # 4.8842828471
    # 4.884282847089863

    # def y(x):
    #     return 3 * np.exp(x/2) - 2

    # t = np.linspace(x0, x0 + n * h, 10)
    # yt = [y(ti) for ti in t]

    # print(yt)
    # plt.plot(t, yt, color="blue")
    # plt.scatter(x_, y_)
    # plt.show()
