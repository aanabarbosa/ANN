import matplotlib.pyplot as plt
import numpy as np

def euler(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        y0 += h * f(x0, y0)
        x0 += h
        vals.append([x0, y0])
    return vals


def euler_mid(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + h / 2, y0 + (h/2) * m1)
        y0 += + h * m2
        x0 += + h
        # print(f'x_{k+1} = {x0}, y_{k+1} = {y0}')
        vals.append([x0, y0])
    return vals

def heun(f, x0, y0, h, n):
    for _ in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + h, y0 + h * m1)
        y0 += h * (m1 + m2) / 2
        x0 += h
        yield [x0, y0]

def ralston(f, x0, y0, h, n):
    for _ in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + 0.75 * h, y0 + 0.75 * h * m1)
        y0 += h * (m1 + 2 * m2) / 3
        x0 += h
        yield [x0, y0]


def rk4(f, x0, y0, h, n):
    r = []
    for _ in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + h/2, y0 + (h/2) * m1)
        m3 = f(x0 + h/2, y0 + (h/2) * m2)
        m4 = f(x0 + h, y0 + h * m3)
        yk = y0 + h * (m1 + 2 * m2 + 2 * m3 + m4) / 6
        # atualizar x0 e y0
        x0 += h
        y0 = yk
        r.append((x0, y0))
    return r

def rk2(f, x0, y0, h, n, b: int=1):
    """
        Runge-Kutta de ordem 2
        por padrão usa o metodo do ponto médio de euler
        que corresponde a b = 1
        b = 1/2 corresponde ao método de Heun
        b = 2/3 corresponde ao método de Ralston
    """
    a = 1 - b
    p = 1 / (2 * b)
    q = p
    for _ in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + h/2, y0 + (h/2) * m1)
        y0 += (a * m1 + b * m2) * h
        x0 += h
        yield [x0, y0]

def diff(a, b):
    return sum((ai - bi) ** 2 for ai, bi in zip(a, b))

if __name__ == '__main__':

    # exemplo 3: y' = 2x^3 + 12x^2 - 20x + 8.5, y(0) = 1
    # solucao algebrica: y(x) = -0.5*x^4 + 4*x^3 - 10*x^2 + 8.5*x + 1
    # use h=0.5 e execute 8 iteracoes

    def f(x, y):
        return -2 * x**3 + 12 * x**2 - 20 * x + 8.5

    x0, y0 = 0, 1
    h = 0.125
    n = 32
    # a variavel que define o rk2
    b = 0.75

    metodo1 = euler(f, x0, y0, h, n)
    metodo2 = euler_mid(f, x0, y0, h, n)
    metodo3 = heun(f, x0, y0, h, n)
    metodo4 = ralston(f, x0, y0, h, n)
    metodo5 = rk2(f, x0, y0, h, n)

    def y(x):
        return -0.5 * x**4 + 4 * x**3 - 10 * x**2 + 8.5 * x + 1

    t = np.linspace(x0, x0 + n * h, 200)
    yt = [y(ti) for ti in t]

    def plot(values):
        xi, yi = zip(*values)
        plt.scatter(xi, yi)
        print(diff(yi, [y(i) for i in xi]))

    plt.plot(t, yt, color='red')
    plot(metodo1)
    plot(metodo2)
    plot(metodo3)
    plot(metodo4)
    plot(metodo5)
    plt.show()
