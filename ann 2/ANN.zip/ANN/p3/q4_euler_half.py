import math
import matplotlib.pyplot as plt
import numpy as np

def euler(f, x0, y0, h, n):
    r = []
    for i in range(n):
        #realizar iteracoes
        m1 = f(x0, y0)
        m2 = f(x0 + h / 2, y0 + (h / 2) * m1)
        yk = y0 + h * m2

        y0 = yk
        x0 += h
        r.append((x0, y0))
    return r

if __name__ == '__main__':

    def f(x, y):
        return k*y + v # função kP + funny V

    x0, y0 = 0.0, 1555933
    k = 0.075
    v = 73632 # funny V que ele dá
    h=0.0625
    n=int(1/h)
    resposta = euler(f, x0, y0, h, n)
    #print(resposta)

    x, y = zip(*resposta)
    print(x)
    print(y)
    plt.scatter(x,y)
    # plt.savefig('euler_half.png')
