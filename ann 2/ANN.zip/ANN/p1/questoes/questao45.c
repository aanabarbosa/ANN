#include <stdio.h>
#include <math.h>

#define ROWS 3
#define COLS 4
double e = 2.718281828459045235360287;
double pi = 3.14159265359;

void print_matrix(double matrix[ROWS][COLS]) {
    for(int i = 0; i < ROWS; i++) {
        for(int j = 0; j < COLS; j++) {
            printf("%.8f\t", matrix[i][j]);
        }
        printf("\n");
    }
}

void gauss(double E[ROWS][COLS]) {
    for ( int j = 0; j < COLS - 2; j++ ) {
        for (int i = j; i < ROWS; i++) {
            if(E[i][j] != 0) {
                // é preciso trocar linhas
                for(int k = 0; k < COLS; k++) {
                    double temp = E[i][k];
                    E[i][k] = E[j][k];
                    E[j][k] = temp;
                }
                // aplicar operacoes elementares em linha
                // a * Lj + Lm -> Lm
                for(int m = j + 1; m < COLS; m++) {
                    double a = -E[m][j] / E[j][j];
                    for (int n = j; n< COLS; n++) {
                        E[m][n] += a * E[j][n];
                    }
                }
                print_matrix(E);
                printf("\n");
                break;
            }
        }
    }
}

void reverse_substitution(double E[ROWS][COLS]) {
    int d = ROWS - 1;
    double temp[ROWS];
    for( int i = 0; i < ROWS; i ++) {
        int j = d -i;
        double soma = E[j][COLS -1];
        for(int k = j + 1; k < COLS -1; k++ ){
            soma -= E[j][k] * temp[k];
        }
        soma /= E[j][j];
        printf("x_%d = %.16f\n", j+1, soma);
        temp[j] = soma;
    }
}


int main() {

    double E[ROWS][COLS] = {
        {0.56, 0.33, 0.33, 3336},
        {0.16, 0.47, 0.15, 2272},
        {0.28, 0.20, 0.52, 3094},
    };


    print_matrix(E);
    printf("\n");
    gauss(E);
    reverse_substitution(E);



    return 0;
}