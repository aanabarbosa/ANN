
g = 9.81
v = 7.12

m1 = 82.7
c1 = 11.88

m2 = 66.42
c2 = 15.35

m3 = 55.89
c3 = 21.3

R = 0
T = 0

# - c1.v + m1.g - T = m1.a
# - c2.v - R + m2.g + T = m2.a
# - c3.v + R + m3.g = m3.a

# x = m1*g - T - c1*v = m1*a
# y = m2*g - R + T - c2*v = m2*a
# z = m3*g + R -c3*v = m3*a

x = m1*g - c1*v
y = m2*g - c2*v
z = m3*g - c3*v

print()

# print(' - ' + str(c3) + ' * ' + str(v) + ' + ' + 'R' + ' + ' + str(m3) + ' * ' + str(g) +' = ' + str(m3) + ' * ' + str(v))
# print(' - ' + str(c2) + ' * ' + str(v) + ' - ' + 'R' + ' + ' + str(m2) + ' * ' + str(g) + ' - ' + 'T' + ' = ' + str(m2) + ' * ' + str(v))
# print(' - ' + str(c1) + ' * ' + str(v) + ' - ' + 'T' + ' + ' + str(m1) + ' * ' + str(g) + ' = ' + str(m1) + ' * ' + str(v))

print('R' + ' - ' + str(m3) + '*a' + ' + 0T' + ' = ' + ' - ' + str(m3*g - c3*v))
print('-' + 'R' + ' - ' + str(m2) + '*a' + ' + ' +
      'T' + ' = ' + ' - ' + str(m2*g - c2*v))
print('0R' + ' - ' + str(m1) + '*a' + ' - ' +
      'T' + ' = ' + ' - ' + str(m1*g - c1*v))

print()

# https://matrix.reshish.com/ptBr/cramSolution.php

# print(str(x)+' - T = '+str(m1)+' * a')
# print(str(y)+' - R + T = '+str(m2)+' * a')
# print(str(z)+' + R = '+str(m3)+' * a')

# a1= 177.08
# a2= 27516.10897
# a3= 1692.0153
# a4= 43778.47710

# print(a2/a1, a3/a1, a4/a1)

# a=8.0922822707925
# r=77.010784069061
# t=66.567560442871


##########

# - c3*v + R + m3*g = m3*a
# -17*5 + R + 40*9.81 = 40*a
# R - 40*a = -307.40

# -c2*v - R + m2*g + T = m2*a
# -14*5 - R + 60*9.81 + T = 60*a
# -R - 60*a +T = -518.60

# -c1*v + m1*g - T = m1*a
# -10*5 - T + 70*9.81  = 70*a
# -70*a - T = -636.70
