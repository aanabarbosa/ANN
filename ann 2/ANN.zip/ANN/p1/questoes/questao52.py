usar lagrange
