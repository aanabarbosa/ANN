import numpy as np
from math import cos, sin, pi

g = 9.81
m1 = 126
m2 = 50
m3 = 43
u1 = 0.1
u2 = 0.24
u3 = 0.41
angulo = 66*pi/180

f1 = u1*m1*g*cos(angulo)
f1h = m1*g*sin(angulo)
bloco1 = f'-T {f1h} -({f1}) = {m1}*a'

f2 = u2*m2*g*cos(angulo)
f2h = m2*g*sin(angulo)
bloco2 = f'+T -R {f2h} -({f2}) = {m2}*a'

f3 = u3*m3*g*cos(angulo)
f3h = m3*g*sin(angulo)
bloco3 = f'+R {f3h} -({f3}) = {m3}*a'

print('bloco1 =', bloco1)
print('bloco2 =', bloco2)
print('bloco3 =', bloco3)

bloco1 = f'-T  {1129.1969983737133 -(50.27508950402737)} = 126*a'
bloco2 = f'+T -R {448.0940469736957 -(47.8810376228832)} = 50*a'
bloco3 = f'+R {385.36088039737837 -(70.34522444095256)} = 43*a'

print('bloco1 =', bloco1)
print('bloco2 =', bloco2)
print('bloco3 =', bloco3)

# bloco1 = -T  1078.921908869686 = 126*a
# bloco2 = +T - R 400.2130093508125 = 50*a
# bloco3 = +R 315.0156559564258 = 43*a

# A = [[1, 0, 126], [-1, 1, 50], [0, -1, 43]]
# b = [1078.921908869686, 400.2130093508125, 315.0156559564258]

# antes deu:

# bloco1 = f'-T {1241.9833256727015 -(479.7477424398747)} = 176*a'
# bloco2 = f'+T -R {832.6933660760159 -(377.93763914368526)} = 118*a'
# bloco3 = f'+R {352.83617206610836 -(183.99416258347463)} = 50*a'

# bloco1 = -T 762.2355832328269 = 176*a
# bloco2 = +T - R 454.7557269323306 = 118*a
# bloco3 = +R 168.84200948263373 = 50*a

# [[1, 0, 176], [-1, 1, 118], [0, -1, 50]]
# [762.2355832328269, 454.7557269323306, 168.84200948263373]

# # dois
# fn = m2*g*cos(angulo)
# f2v = fn
# f2 = u2*f2v

# px = m2*g*sin(angulo)
# f2h = px
# bloco2 = f'{f2h} -R + T -({f2}) = {m2}*a'

# # tres
# fn = m3*g*cos(angulo)
# f3v = fn
# f3 = u3*f3v

# px = m3*g*sin(angulo)
# f3h = px
# bloco3 = f'{f3h} + R -({f3}) = {m3}*a'

# # bloco1 = f'-T + {f1h - f1} = {m1}*a'
# # bloco2 = f'-R + T + {f2h - f2} = {m2}*a'
# # bloco3 = f'+R + {f3h-f3} = {m3}*a'

# # a = f'[[-1, 0, {m1}],[1, -1, {m2}],[0, 1, {m3}]]'
# # b = f'[{f1h - f1}, {f2h - f2}, {f3h-f3}]'

# # print('A =', a)
# # print('b =', b)

# # bloco1 = f'{fh(u1, m1)} -T  +0R -({fv(m1)}) = {m1} * a'
# # bloco2 = f'{fh(u2, m2)} +T  -R  -({fv(m2)}) = {m2} * a'
# # bloco3 = f'{fh(u3, m3)} +0T +R  -({fv(m2)}) = {m3} * a'

# print('bloco1 = ', bloco1)
# print('bloco2 = ', bloco2)
# print('bloco3 = ', bloco3)


# # resposta esperada:
# # a = 4.0285852315343
# # T = 53.204582482794
# # R = 32.58725209408
