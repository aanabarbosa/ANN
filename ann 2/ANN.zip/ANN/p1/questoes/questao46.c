#include <stdio.h>
#include <math.h>

#define ROWS 3
#define COLS 4
double e = 2.718281828459045235360287;
double pi = 3.14159265359;

void print_matrix(double matrix[ROWS][COLS]) {
    for(int i = 0; i < ROWS; i++) {
        for(int j = 0; j < COLS; j++) {
            printf("%.8f\t", matrix[i][j]);
        }
        printf("\n");
    }
}

void gauss(double E[ROWS][COLS]) {
    for ( int j = 0; j < COLS - 2; j++ ) {
        for (int i = j; i < ROWS; i++) {
            if(E[i][j] != 0) {
                // é preciso trocar linhas
                for(int k = 0; k < COLS; k++) {
                    double temp = E[i][k];
                    E[i][k] = E[j][k];
                    E[j][k] = temp;
                }
                // aplicar operacoes elementares em linha
                // a * Lj + Lm -> Lm
                for(int m = j + 1; m < COLS; m++) {
                    double a = -E[m][j] / E[j][j];
                    for (int n = j; n< COLS; n++) {
                        E[m][n] += a * E[j][n];
                    }
                }
                print_matrix(E);
                printf("\n");
                break;
            }
        }
    }
}

void reverse_substitution(double E[ROWS][COLS]) {
    int d = ROWS - 1;
    double temp[ROWS];
    for( int i = 0; i < ROWS; i ++) {
        int j = d -i;
        double soma = E[j][COLS -1];
        for(int k = j + 1; k < COLS -1; k++ ){
            soma -= E[j][k] * temp[k];
        }
        soma /= E[j][j];
        printf("x_%d = %.16f\n", j+1, soma);
        temp[j] = soma;
    }
}


int main() {

    double E[ROWS][COLS] = {
           {1, 1, -1, 0},
            {27, 0, 9, 59},
            {26, 0, 27, 151},
    };


    print_matrix(E);
    printf("\n");
    gauss(E);
    reverse_substitution(E);


    // i1 + i2 = i3

    // v1 = 59
    // v2 = 46
    // r1 = 9
    // r2 = 26
    // r3 = 27

    // no a
    // i1 + i2 = i3
    // no b
    // i3 = i1 + i2

    // i1 + i2 - i3 = 0

    // v1 = r3*i1 + r1*i3
    // v2 + r2*i2 + r3*i3 = 0
    // v2 + v1 + r2*i2 = r2*i1

    // 27*i1 + 9*i3 = 59
    // 26*i2 + 27*i3 = -46
    // 26*i2 - 26*i1 = -105

    // 27*i1 + 9*i3 = 59
    // 26*i2 + 27*i3 = -46 ----- 26*i2 - 26*i1 = -105 ==== 27*i3 +26*i1 = 151
    //

    // esperado tentativa 1
    // 3.7056827820187
    // 2.7557251908397
    // 0.94995759117897

    return 0;
}