

k1 = 490
k2 = 527
k3 = 1097
k4 = 380
k5 = 359
k6 = 310
k7 = 353

x = 'x'
x1 = 'x1'
x2 = 'x2'
x3 = 'x3'

print(f'{k7} + {x3} = {x} + {k6}')
print(f'{k5} + {k4} = {x2} + {x3}')
print(f'{x2} + {x1} = {k3}')
print(f'{k1} + {k2} = {k7} + {x1}')

print()

print(f'{k7} + {x3} = {x} + {k6}')
print(f'{k5 + k4} = {x2} + {x3}')
print(f'{x2} + {x1} = {k3}')
print(f'{k1 + k2} = {k7} + {x1}')

print()

print(f'{k7} + {x3} = {x} + {k6}')
print(f'{k5 + k4} = {x2} + {x3}')
print(f'{x2} + {x1} = {k3}')
print(f'{k1 + k2} = {k7} + {x1}')
