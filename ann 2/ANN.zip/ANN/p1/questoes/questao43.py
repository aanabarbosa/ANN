import numpy as np
from math import cos, sin, pi

alpha = 24*pi/180
beta = 57*pi/180
F = 1767

# zero = -F1*cos(alpha)+f3*cos(beta)+f1h

# 1) a soma de todas as forças horizontais agindo em cada nó é zero
# 2) a soma de todas as forças verticais agindo em cada nó é zero

# no 1
# F_h = -F1*cos(alpha) + F3*cos(beta) + F1h
# F_v = -F1*sin(alpha) - F3*sin(beta) + F1v

# # no 2
# F_h = F2 + F1*cos(alpha) + F2h + H2
# F_v = F1*sin(alpha) + F2v + V2

# # no 3
# F_h = -F2 - F3*cos(beta) + F3h
# F_v = F3*sin(beta) + F3v + V3

f1 = 0
f2 = 0
f3 = 0
h2 = 0
v2 = 0
v3 = 0
f1h = '0, 0, 0'
f1v = '0, 0, 0'
f2h = '-1, 0, 0'
f2v = '0, -1, 0'
f3h = '0, 0, 0'
f3v = '0, 0, -1'

no1Fh = f'[{cos(alpha)}, {0}, {-cos(beta)}, {f1h}]'
no1Fv = f'[{sin(alpha)}, {0}, {sin(beta)}, {f1v}]'

no2Fh = f'[{-cos(alpha)}, {-1}, {0}, {f2h}]'
no2Fv = f'[{-sin(alpha)}, {0}, {0}, {f2v}]'

no3Fh = f'[{0}, {1}, {cos(beta)}, {f3h}]'
no3Fv = f'[{0}, {0}, {-sin(beta)}, {f3v}]'

m = [eval(no1Fh), eval(no1Fv), eval(no2Fh),
     eval(no2Fv), eval(no3Fh), eval(no3Fv)]

A = np.array(m)
print('matriz =')
print(A)

print('inversa =')
print(np.linalg.inv(A))

X = [f1, f2, f3, h2, v2, v3]
B = [0, -F, 0, 0, 0, 0]
F_t = [f1h, f1v, f2h, f2v, f3h, f3v]

print('resposta = ', np.linalg.solve(A, B))
