import matplotlib.pyplot as plt
import numpy as np


def dif_div(x, y):
    num = len(x)
    Y = [yi for yi in y]
    coefs = [y[0]]
    for j in range(num-1):
        for i in range(num-1-j):
            numer = Y[i + 1] - Y[i]
            denom = x[i + 1 + j] - x[i]
            div = numer / denom
            Y[i] = div
        coefs.append(Y[0])
    return coefs


def poly(t, x, coefs):
    val = 0
    num = len(coefs)
    for i in range(num):
        prod = 1
        for j in range(i):
            prod *= (t - x[j])
        val += coefs[i] * prod
    return val


def build_func(x, coefs):
    def temp(t):
        return poly(t, x, coefs)
    return temp


def main():
    # x = [0.067, 0.379, 1.394]
    # y = [3.046, 2.711, 0.761]

    x = [-2.515, -1.123, -0.451, 0.98, 2.232, 2.653, 3.767]
    y = [1.781, 1.456, 3.349, 1.793, 1.523, 1.871, 1.782]

    coefs = dif_div(x, y)
    p = build_func(x, coefs)

    print(coefs)
    print(p(1), p(2), p(3))

    # visualizacao
    t = np.linspace(min(x), max(x), 100)
    pt = [p(ti) for ti in t]

    plt.scatter(x, y)
    plt.plot(t, pt)
    plt.show()


main()
