import math


def f(x):
    return (12 * ((x*x) - (8.57*x) + 13.0677))


def df(x):
    return (12 * ((2*x) - 8.57))


def newton(x0, n):
    der = df(x0)
    if(der == 0):
        print('Escolha outra estimativa inicial')
    else:
        for i in range(n):
            x1 = x0 - f(x0) / der
            der = df(x1)
            if(der == 0):
                print("x_%d = %.16f (precisei parar)" % (i+1, x1))
                return
            else:
                print("x_%d = %.16f" % (i+1, x1))
            x0 = x1


def main():

    # x = sy.Symbol('x')
    # funcao = sy.sqrt(2*G*x) * sy.tanh((sy.sqrt(2*G*x)/2*L)*T) - V
    # resultado = sy.diff(funcao)
    # print(resultado)

    n = 5
    x0 = 3.41
    newton(x0, n)


main()
