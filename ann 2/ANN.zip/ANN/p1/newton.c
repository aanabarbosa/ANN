#include <stdio.h>
#include <math.h>

void newton(double (*f)(double), double (*df)(double), double x0, int n ){
    double der = df(x0);
    if( der == 0) {
        printf("Derivative is zero\n");
    } else {
        for(int i = 0; i < n; i++){
            double x1 = x0 - f(x0)/der;
            der = df(x1);
            if(der == 0) {
                printf("x_%d = %.16f (precisei parar)\n", i + 1, x1);
                return;
            } else {
                printf("x_%d = %.16f\n", i + 1, x1);
            }
            x0 = x1;
        }
    }

}

double f(double x) {
    double g = 9.81;
    double t = 9.37;
    double v = 9.97;
    double l = 7.32;

    return (sqrt(2*g*x) * tanh((sqrt(2*g*x)/2*l)*t)) - v;
}

double df(double x) {
    return 6.27867 * 1/pow(cosh(2.83497*sqrt(x)), 2) + (2.21472 * tanh(2.83497 * sqrt(x))) / sqrt(x);
}

int main() {
    double x0 = 1.49;
    int n = 5;

    newton(f, df, x0, n);
}