#include <stdio.h>
#include <math.h>

#define ROWS 6
#define COLS 7
double e = 2.718281828459045235360287;
double pi = 3.14159265359;

void print_matrix(double matrix[ROWS][COLS]) {
    for(int i = 0; i < ROWS; i++) {
        for(int j = 0; j < COLS; j++) {
            printf("%.8f\t", matrix[i][j]);
        }
        printf("\n");
    }
}

void gauss(double E[ROWS][COLS]) {
    for ( int j = 0; j < COLS - 2; j++ ) {
        for (int i = j; i < ROWS; i++) {
            if(E[i][j] != 0) {
                // é preciso trocar linhas
                for(int k = 0; k < COLS; k++) {
                    double temp = E[i][k];
                    E[i][k] = E[j][k];
                    E[j][k] = temp;
                }
                // aplicar operacoes elementares em linha
                // a * Lj + Lm -> Lm
                for(int m = j + 1; m < COLS; m++) {
                    double a = -E[m][j] / E[j][j];
                    for (int n = j; n< COLS; n++) {
                        E[m][n] += a * E[j][n];
                    }
                }
                print_matrix(E);
                printf("\n");
                break;
            }
        }
    }
}

void reverse_substitution(double E[ROWS][COLS]) {
    int d = ROWS - 1;
    double temp[ROWS];
    for( int i = 0; i < ROWS; i ++) {
        int j = d -i;
        double soma = E[j][COLS -1];
        for(int k = j + 1; k < COLS -1; k++ ){
            soma -= E[j][k] * temp[k];
        }
        soma /= E[j][j];
        printf("x_%d = %.16f\n", j+1, soma);
        temp[j] = soma;
    }
}


int main() {
    // double E[ROWS][COLS] = {
    //     {2, 4, 6, 2, 4},
    //     {1, 2, -1, 3, 8},
    //     {-3, 1, -2, 1, -2},
    //     {1, 3, -3, -2, 6}
    // };

    // questao 43
    double F4 = 947;
    double F5 = 1139;
    double F6 = 662;

    double alpha = 55;
    double beta = 55;
    double teta1 = 46;
    double teta2 = 61;
    double teta3 = 46;

    alpha = (alpha * pi) / 180;
    beta = (beta * pi) / 180;
    teta1 = (teta1 * pi) / 180;
    teta2 = (teta2 * pi) / 180;
    teta3 = (teta3 * pi) / 180;

    double F1h = -F4*cos(teta1);
    double F1v = -F4*sin(teta1);
    double F2h = F5*cos(teta2);
    double F2v = -F5*sin(teta2);
    double F3h = -F6*cos(teta3);
    double F3v = -F6*sin(teta3);

    // F1, F2, F3, H2, V2, V3,
    double E[ROWS][COLS] = {
        {cos(alpha) , 0, -cos(beta), 0, 0, 0, F1h},
        {sin(alpha) , 0, sin(beta), 0, 0, 0, F1v},
        {-cos(alpha), -1, 0, -1, 0, 0, F2h},
        {-sin(alpha), 0, 0, 0, -1, 0, F2v},
        { 0, 1, cos(beta), 0, 0, 0, F3h},
        { 0, 0, -sin(beta), 0, 0, -1, F3v}
    };

    print_matrix(E);
    printf("\n");
    gauss(E);
    reverse_substitution(E);


    return 0;
}