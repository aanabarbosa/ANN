#include <stdio.h>
#include <math.h>

void bisec(double (*f)(double), double a, double b, int n ){
   if( f(a) * f(b) >= 0) {
       printf("não e possivel calcular bolzano em [%f, %f]", a, b);
   } else {
       for( int i = 0; i < n; i++) {
           double m = 0.5 * (a-b);
           printf("x_%d = %.16f", i + 1, m);
           if(f(m) == 0) {
               printf("você encontrou a raiz r = %.16f", m);
           } else {
               if ( f(m) * f(a) < 0) {
                   b = m;
               } else {
                   a = m;
               }
           }
       }
   }
}

double func(double m) {
    double c = 17.89;
    double v = 31.57;
    double t = 8.56;
    double g = 9.81;

    return ((g*m)/c)*(1-exp(-(c/m)*t))-v;
}

int main() {
    double a = 20.22;
    double b = 185.12;
    int n = 12;

    bisec(func, a, b, n);
}