def jaco(matrix_a, matrix_b, chute, n):
    next = [0 for i in range(len(matrix_a))]
    for k in range(n):
        for i in range(len(matrix_a)):
            bi = matrix_b[i]
            for j in range(len(matrix_a)):
                if(j != i):
                    bi -= matrix_a[i][j] * chute[j]
            bi /= matrix_a[i][i]
            print('x_%d^(%d) = %.16f\t' % (i+1, k+1, bi))
            next[i] = bi
        for i in range(len(matrix_a)):
            chute[i] = next[i]


def main():
    matrix_a = [
        [-6.02, 2.69, 2.28],
        [-1.19, -6.16, -3.9],
        [0.42, 3.11, 4.59],
    ]
    matrix_b = [-1.22, 0.11, 4.33, 3.42]
    chute = [-3.3, 1.16, -2.4, 0.07]
    n = 18

    jaco(matrix_a, matrix_b, chute, n)


main()
