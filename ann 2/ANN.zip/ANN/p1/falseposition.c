#include <stdio.h>
#include <math.h>

void fpos(double (*f) (double),double a, double b, int n ){
    double fa = f(a);
    double fb = f(b);

    if(fa*fb >=0){
        printf("nao sei se dizer se f possui uma raiz no intervalo [%f][%f]",a,b);
        return;
    }
    else{
        for (int i=0;i<n;i++){
            double x = (a*fb-b*fa) / (fb-fa);
            printf("x_%d = %.7f\n",i+1,x);
            double fx = f(x);

            if (fx ==0){
                printf("A raiz procurada e: x= %.16f",x);
                return;
            }
            else{
                if(fa*fx <0){
                    b=x;
                    fb= fx;
                }
                else{
                    a=x;
                    fa=fx;
                }}
        }
    }
}

// double f(double x){
//     //return (-35.6+((9.81*x)/22.39)*(1-(pow(M_E,-(22.39/x)*9.36)))); //function;
//     double g = 9.81;
//     double t = 9.37;
//     double v = 9.97;
//     double l = 7.32;

//     return sqrt(2*g*x) * tanh( (sqrt(2*g*x)/(2*l))*t) - v;

// }

double f(double m) {
    double c = 17.89;
    double v = 31.57;
    double t = 8.56;
    double g = 9.81;

    return ((g*m)/c)*(1-exp(-(c/m)*t))-v;
}

int main(void){

    double a =  35.0;
    double b = 190.1;
    int n = 11;

    fpos(f, a, b, n);

    return 0;
}