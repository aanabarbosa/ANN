import math


def print_matrix(e):
    rows = len(e)
    cols = len(e[0])
    for i in range(rows):
        for j in range(cols):
            print(e[i][j], end='\t')
        print()


def gau(e):
    rows = len(e)
    cols = len(e[0])
    for j in range(cols - 2):
        for i in range(j, rows):
            if(e[i][j] != 0):
                # é preciso trocar linhas
                for k in range(cols):
                    temp = e[i][k]
                    e[i][k] = e[j][k]
                    e[j][k] = temp
                #  aplicar operacoes elementares em linha
                #  a * Lj + Lm -> Lm
                for m in range(j+1, cols):
                    a = -e[m][j] / e[j][j]
                    for n in range(j, cols):
                        e[m][n] = a * e[j][n] + e[m][n]
                print_matrix(e)
                print()
                break


def reversesub(e):
    rows = len(e)
    cols = len(e[0])
    d = rows - 1
    temp = [0 for _ in e]
    for i in range(rows):
        j = d - i
        soma = e[j][cols - 1]
        for k in range(j+1, cols):
            soma -= e[j][k] * temp[k]
        soma /= e[j][j]
        print('x^%d = %.16f' % (j, soma))
        temp[j] = soma


def main():

    e = [
        [2,  4,  6,  2],
        [1,  2, -1,  3],
        [-3, 1, -2,  1],
    ]

    print_matrix(e)
    print()
    gau(e)
    # reversesub(e)


main()
