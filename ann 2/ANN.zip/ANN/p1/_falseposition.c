#include <stdio.h>
#include <math.h>

void false(double (*f)(double), double a, double b, int n) {
    double fa = f(a);
    double fb = f(b);
    if( fa * fb >= 0) {
        printf("No root in [%.16f, %.16f]\n", a, b);
        return;
    } else {
        for(int i = 0; i < n; i++) {
            double x = (a * fb - b * fa) / (fb - fa);
            printf("x_%d = %.16f\n", i + 1, x);
            double fx = f(x);
            if(fx == 0) {
                printf("encontramos uma raiz para f, ela é x = %.16f\n", x);
                return;
            }
            if(fx * fa < 0) {
                b = x;
                fb = fx;
            } else {
                a = x;
                fa = fx;
            }
        }
    }
}

double f(double x) {
    double G = 9.81;
    double T = 8.1;
    double V = 10.87;
    double L = 7.37;

    double result = (sqrt(2*G*x) * tanh((sqrt(2*G*x)/2*L)*T)) - V;
    return result;
}

int main() {
    double a = 0.48;
    double b = 15.66;
    int n = 11;

    false(f, a, b, n);
}