import math

G = 9.81
C = 17.89
V = 31.57
T = 8.56


def f(x):
    return (((G*x/C)*(1-math.exp(-(C/x)*T)))) - V


def bisec(a, b, n):
    if (f(a) * f(b) >= 0):
        print('nao e possivel usar bolzano em', a, b)
    else:
        for i in range(n):
            m = 0.5 * (a + b)
            print("x_%d = %.16f" % (i+1, m))
            if(f(m) == 0):
                print('yay vc encontrou raiz r = %.16f' % (m))
            else:
                if(f(a)*f(m) < 0):
                    b = m
                else:
                    a = m


def main():
    a = 20.22
    b = 185.12
    n = 12
    bisec(a, b, n)


main()


# 15: ((P0*math.exp(x*T)) + ((V/x) * (math.exp(x*T)-1))) - P
# 16: (((G*x/C)*(1-math.exp(-(C/x)*T)))) - V
# 17: (math.sqrt(2*G*x) * math.tanh((math.sqrt(2*G*x)/2*L)*T)) - V
# 18: A = (4.49 * y) + (y*y / 2)
#     return 1 - (( (Q*Q)/ (9.81*A*A*A)) * (4.49 + y))
# 20:
# VS = (4/3)*math.pi*(R*R*R)
# V = -((PS*VS - PW*VS)/PW)
# def f(h):
#     return (((math.pi*h*h)/3)*(3*R-h)) - V
# 21:
#     return L*(0.5*math.pi*R*R - R*R*arcsin(h/R)-h*math.sqrt((R*R)-(h*h))) - V
# 22: ( -(g/(2*x*x)) * (math.sinh(x*t)-math.sin(x*t)) ) - Xt
# 23: ( (12*x*x) - (113.32*x) + 181.2432)
# 24: ( (n+1) / (1 + (n*math.exp(-lam*(n+1)*t)) ) ) - n/4
