#include <stdio.h>
#include <math.h>

int main() {
    // eemplo
    // x^2+2y^2 = 6 -> g1(x,y) = x^2 + 2y^2 - 6
    // x^2-y = 3 -> g2(x,y) = x^2 - y - 3
    // uma solução é (2,1) e (-2,1)
    double g1(double x, double y) {
        return x * x + 2 * y * y - 6;
    }

    double g2(double x, double y) {
        return x * x - y - 3;
    }

    double g1x(double x, double y) {
        return 2 * x;
    }

    double g1y(double x, double y) {
        return 4 * y;
    }

    double g2x(double x, double y) {
        return 2 * x;
    }

    double g2y(double x, double y) {
        return -1;
    }

    double det(double x, double y) {
        // retorna determiannante de
        // [g1x, g1y]
        // [g2x, g2y]
        return g1(x, y) * g2(x, y) - g1x(x, y) * g2y(x, y);
    }

    void newton(double x, double y, int n) {
        for(int k = 0; k < n; k++) {
            double d = det(x, y);
            if(d ==0) {
                printf("não é possivel continuar");
                return;
            }
            double xk = x - (g2y(x, y) * g1(x, y) - g1y(x, y) * g2(x, y)) / d;
            double yk = y - (-g2x(x, y) * g1(x, y) + g1x(x, y) * g2(x, y)) / d;
            printf("x^(%d) = %.16f\n", k + 1, xk);
            printf("y^(%d) = %.16f\n\n", k + 1, yk);
            x = xk;
            y = yk;
        }
    }

    double x0 = -1;
    double y0 = 0
    int n = 10;

    newton(x0, y0, n);
}